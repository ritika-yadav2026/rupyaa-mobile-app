package com.collectdata;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.module.annotations.ReactModule;

import com.credeau.collectdevicedata.DataDeviceDataCallback;
import com.credeau.collectdevicedata.DataDeviceDataOutputCallback;
import com.credeau.collectdevicedata.DeviceDataManager;
import com.credeau.collectdevicedata.SDKCollectMessagingService;

import com.facebook.react.bridge.ReadableMapKeySetIterator;


import android.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableNativeArray;
import java.util.Iterator;
import com.facebook.react.bridge.ReadableArray;
import com.google.firebase.messaging.RemoteMessage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 

public class CollectDataReactModule extends ReactContextBaseJavaModule {
    private static final String MODULE_NAME = "CollectDataReact";

    public CollectDataReactModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return MODULE_NAME;
    }

    public WritableMap convertJsonToMap(JSONObject jsonObject) throws JSONException {
        WritableMap map = Arguments.createMap();

        Iterator<String> iterator = jsonObject.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            Object value = jsonObject.get(key);

            if (value instanceof JSONObject) {
                map.putMap(key, convertJsonToMap((JSONObject) value));
            } else if (value instanceof JSONArray) {
                WritableArray arr = convertJsonToArray((JSONArray) value);
                map.putArray(key, arr);
            } else if (value instanceof Boolean) {
                map.putBoolean(key, (Boolean) value);
            } else if (value instanceof Integer) {
                map.putInt(key, (Integer) value);
            } else if (value instanceof Double) {
                map.putDouble(key, (Double) value);
            } else if (value instanceof String) {
                map.putString(key, (String) value);
            } else {
                map.putString(key, value.toString());
            }
        }
        return map;
    }

    public WritableArray convertJsonToArray(JSONArray jsonArray) throws JSONException {
        WritableArray array = new WritableNativeArray();

        for (int i = 0; i < jsonArray.length(); i++) {
            Object value = jsonArray.get(i);
            if (value instanceof JSONObject) {
                array.pushMap(convertJsonToMap((JSONObject) value));
            } else if (value instanceof JSONArray) {
                array.pushArray(convertJsonToArray((JSONArray) value));
            } else if (value instanceof Boolean) {
                array.pushBoolean((Boolean) value);
            } else if (value instanceof Integer) {
                array.pushInt((Integer) value);
            } else if (value instanceof Double) {
                array.pushDouble((Double) value);
            } else if (value instanceof String) {
                array.pushString((String) value);
            } else {
                array.pushString(value.toString());
            }
        }
        return array;
    }

    @ReactMethod
    public void disableSyncs(ReadableArray disableSyncs) {
        String[] stringArray = new String[disableSyncs.size()];
        for (int i = 0; i < disableSyncs.size(); i++) {
            stringArray[i] = disableSyncs.getString(i);
        }
        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), "", "", "");
        dataMgr.disableSyncs(stringArray);
    }

    @ReactMethod
    public void setDeviceMatchParams(String fullname, String phoneNumber, String email) {

        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), "", "", "");
        dataMgr.setDeviceMatchParams(fullname, phoneNumber, email);

    }

    @ReactMethod
    public void initializeFirebase(Promise promise) {
        try {

            SDKCollectMessagingService credService = new SDKCollectMessagingService(getReactApplicationContext());
            credService.initialize();
            promise.resolve("Firebase initialized!");

        } catch (Exception e) {
            promise.reject("FIREBASE FAILED", "Failed to initialize firebase" + e.getMessage());
        }
    }

    @ReactMethod
    public void isDeviceDataCollectionNotification(ReadableMap messageData, Promise promise) {
        try {

           RemoteMessage remoteMessage = convertToRemoteMessage(messageData);

           boolean result = SDKCollectMessagingService.isDeviceDataCollectionNotification(remoteMessage);

           promise.resolve(result);

        } catch (Exception e) {
            promise.reject("NOTIFICATION_CHECK_ERROR", "Failed to check notification type: " + e.getMessage());
        }
    }

    @ReactMethod
    public void triggerOnMessageReceived(ReadableMap message, Promise promise) {
       
        try {

            RemoteMessage remoteMessage = convertToRemoteMessage(message);
            SDKCollectMessagingService collectMessagingService = new SDKCollectMessagingService(getReactApplicationContext());
            collectMessagingService.triggerOnMessageReceived(remoteMessage);
            promise.resolve("Notification triggered successfully!");

        } catch (Exception e) {
            promise.reject("NOTIFICATION_TRIGGER_ERROR", "Failed to trigger notification: " + e.getMessage());        
        }
        
    }
    
    private RemoteMessage convertToRemoteMessage(ReadableMap messageData) {
       
        Map<String, String> dataMap = new HashMap<>();

        if (messageData.hasKey("data")) {
            ReadableMap data = messageData.getMap("data");
            ReadableMapKeySetIterator iterator = data.keySetIterator();
            
            while (iterator.hasNextKey()) {
                String key = iterator.nextKey();
                String value = data.getString(key);
                dataMap.put(key, value);
            }
        }

        return new RemoteMessage.Builder("fake_sender_id@fcm.googleapis.com")
                .setData(dataMap)
                .build();

    }

   
    @ReactMethod
    public void startBackGroundSyncProcess(String user_id, String client_name, String client_key, String server_url, Integer gap_seconds, Promise promise) {
        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
        dataMgr.setUsername(user_id);
        final Integer[] successMessageCount = {0};
        final Integer[] statusMessageCount = {0};
        dataMgr.startBackGroundSyncProcess(new DataDeviceDataCallback() {
            @Override
            public void onSuccess() {
                successMessageCount[0] = successMessageCount[0] + 1;
                statusMessageCount[0] = statusMessageCount[0] + 1;
                if(successMessageCount[0] == 3) {
                    promise.resolve("Data Synced and Background Process Started");
                } else if (statusMessageCount[0] == 3) {
                    promise.resolve("Data Synced Partially");
                }
            }
            @Override
            public void onFailure(String errorMsg) {
                Log.e("GatorSDK", errorMsg);
                statusMessageCount[0] = statusMessageCount[0] + 1;
                if ((statusMessageCount[0] == 3) && (successMessageCount[0] > 1)) {
                    promise.resolve("Data Synced Partially");
                } else if (statusMessageCount[0] == 3) {
                    promise.reject("GatorSDK", errorMsg);
                }
            }
        }, gap_seconds.longValue());
    }

    @ReactMethod  
    public void syncAllData(String user_id, String client_name, String client_key, String server_url, Promise promise) {
        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
        dataMgr.setUsername(user_id);
        final Integer[] successMessageCount = {0};
        final Integer[] statusMessageCount = {0};
        dataMgr.syncAllData(new DataDeviceDataCallback() {
            @Override
            public void onSuccess() {
                successMessageCount[0] = successMessageCount[0] + 1;
                statusMessageCount[0] = statusMessageCount[0] + 1;
                if(successMessageCount[0] == 2) {
                    promise.resolve("Data Synced");
                } else if (statusMessageCount[0] == 2) {
                    promise.resolve("Data Synced Partially");
                }
            }
            @Override
            public void onFailure(String errorMsg) {
                Log.e("GatorSDK", errorMsg);
                statusMessageCount[0] = statusMessageCount[0] + 1;
                if ((statusMessageCount[0] == 2) && (successMessageCount[0] > 0)) {
                    promise.resolve("Data Synced Partially");
                } else if (statusMessageCount[0] == 2) {
                    promise.reject("GatorSDK", errorMsg);
                }
            }
        });
    }

    @ReactMethod  
    public void syncDeviceLocationAppsData(String user_id, String client_name, String client_key, String server_url, Promise promise) {
        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
        dataMgr.setUsername(user_id);
        final Integer[] successMessageCount = {0};
        dataMgr.syncDeviceLocationAppsData(new DataDeviceDataCallback() {
            @Override
            public void onSuccess() {
                promise.resolve("Data Synced");
            }
            @Override
            public void onFailure(String errorMsg) {
                Log.e("GatorSDK", errorMsg);
                promise.reject("GatorSDK", errorMsg);
            }
        });
    }

    @ReactMethod  
    public void syncSMSData(String user_id, String client_name, String client_key, String server_url, Promise promise) {
        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
        dataMgr.setUsername(user_id);
        final Integer[] successMessageCount = {0};
        dataMgr.syncSMSData(new DataDeviceDataCallback() {
            @Override
            public void onSuccess() {
                promise.resolve("Data Synced");
            }
            @Override
            public void onFailure(String errorMsg) {
                Log.e("GatorSDK", errorMsg);
                promise.reject("GatorSDK", errorMsg);
            }
        });
    }

    // @ReactMethod  
    // public void syncCallLogsData(String user_id, String client_name, String client_key, String server_url, Promise promise) {
    //     DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
    //     dataMgr.setUsername(user_id);
    //     final Integer[] successMessageCount = {0};
    //     dataMgr.syncCallLogsData(new DataDeviceDataCallback() {
    //         @Override
    //         public void onSuccess() {
    //             promise.resolve("Call Logs Synced");
    //         }
    //         @Override
    //         public void onFailure(String errorMsg) {
    //             Log.e("GatorSDK", errorMsg);
    //             promise.reject("GatorSDK", errorMsg);
    //         }
    //     });
    // }

    // @ReactMethod  
    // public void syncContactsData(String user_id, String client_name, String client_key, String server_url, Promise promise) {
    //     DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
    //     dataMgr.setUsername(user_id);
    //     final Integer[] successMessageCount = {0};
    //     dataMgr.syncContactsData(new DataDeviceDataCallback() {
    //         @Override
    //         public void onSuccess() {
    //             promise.resolve("Contacts Synced");
    //         }
    //         @Override
    //         public void onFailure(String errorMsg) {
    //             Log.e("GatorSDK", errorMsg);
    //             promise.reject("GatorSDK", errorMsg);
    //         }
    //     });
    // }

    @ReactMethod  
    public void stopBackGroundSyncProcess(Promise promise) {
        DeviceDataManager.stopBackGroundSyncProcess(getReactApplicationContext(), new DataDeviceDataCallback() {
            @Override
            public void onSuccess() {
                promise.resolve("Background Process Stopped");
            }
            @Override
            public void onFailure(String errorMsg) {
                Log.e("GatorSDK", errorMsg);
                promise.reject("GatorSDK", errorMsg);
            }
        });
    }

    @ReactMethod
    public void fetchDeviceData(String user_id, String client_name, String client_key, String server_url, Promise promise) {
        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
        dataMgr.setUsername(user_id);
        final Integer[] successMessageCount = {0};
        dataMgr.fetchDeviceData(new DataDeviceDataOutputCallback() {
            @Override
            public void onSuccess(JSONObject data) {
                promise.resolve(data.toString());
            }
            @Override
            public void onFailure(String errorMsg) {
                Log.e("GatorSDK", errorMsg);
                promise.reject("GatorSDK", errorMsg);
            }
        });
    }

    // @ReactMethod
    // public void fetchCallLogsData(String user_id, String client_name, String client_key, String server_url, String date_from, Promise promise) {
       
    //     Date dtFrom = null;
    //     SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        
    //     try {
    //         dtFrom = formatter.parse(date_from);
    //     } catch (ParseException e) {
    //         Log.e("DataCollect", e.toString());
    //     }
       
    //     DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
    //     dataMgr.setUsername(user_id);
    //     final Integer[] successMessageCount = {0};
    //     dataMgr.fetchCallLogsData(dtFrom,new DataDeviceDataOutputCallback() {
    //         @Override
    //         public void onSuccess(JSONObject data) {
    //             promise.resolve(data.toString());
    //         }
    //         @Override
    //         public void onFailure(String errorMsg) {
    //             Log.e("GatorSDK", errorMsg);
    //             promise.reject("GatorSDK", errorMsg);
    //         }
    //     });
    // }

    // @ReactMethod
    // public void fetchContactsData(String user_id, String client_name, String client_key, String server_url, String date_from, Promise promise) {
      
    //    Date dtFrom = null;
    //     SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        
    //     try {
    //         dtFrom = formatter.parse(date_from);
    //     } catch (ParseException e) {
    //         Log.e("DataCollect", e.toString());
    //     }
      
    //     DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
    //     dataMgr.setUsername(user_id);
    //     final Integer[] successMessageCount = {0};
    //     dataMgr.fetchContactsData(dtFrom, new DataDeviceDataOutputCallback() {
    //         @Override
    //         public void onSuccess(JSONObject data) {
    //             promise.resolve(data.toString());
    //         }
    //         @Override
    //         public void onFailure(String errorMsg) {
    //             Log.e("GatorSDK", errorMsg);
    //             promise.reject("GatorSDK", errorMsg);
    //         }
    //     });
    // }
    
    @ReactMethod
    public void fetchSMSInfo(String user_id, String client_name, String client_key, String server_url, String date_from, Promise promise) {
      
        Date dtFrom = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        
        try {
            dtFrom = formatter.parse(date_from);
        } catch (ParseException e) {
            Log.e("DataCollect", e.toString());
        }

        DeviceDataManager dataMgr = new DeviceDataManager(getReactApplicationContext(), client_name, client_key, server_url);
        dataMgr.setUsername(user_id);
        final Integer[] successMessageCount = {0};
        dataMgr.fetchSMSInfo(dtFrom, new DataDeviceDataOutputCallback() {
            @Override
            public void onSuccess(JSONObject data) {
                promise.resolve(data.toString());
            }
            @Override
            public void onFailure(String errorMsg) {
                Log.e("GatorSDK", errorMsg);
                promise.reject("GatorSDK", errorMsg);
            }
        });
    }
}