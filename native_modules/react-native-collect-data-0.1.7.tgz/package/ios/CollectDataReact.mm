#import <React/RCTBridgeModule.h>

@interface RCT_EXTERN_MODULE(CollectDataReact, NSObject)

RCT_EXTERN_METHOD(multiply:(float)a withB:(float)b
                 withResolver:(RCTPromiseResolveBlock)resolve
                 withRejecter:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(syncDeviceLocationAppsData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(syncSMSData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(syncAllData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
//RCT_EXTERN_METHOD(syncContactsData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
//RCT_EXTERN_METHOD(syncCallLogsData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(startBackGroundSyncProcess:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL gapSeconds:(double)gapSeconds  resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(stopBackGroundSyncProcess:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(fetchDeviceData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(fetchSMSInfo:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL dateFrom:(NSString *)dateFrom resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(disableSyncs:(NSArray<NSString *> *)syncsDisabled)
//RCT_EXTERN_METHOD(fetchContactsData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL dateFrom:(NSString *)dateFrom resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
//RCT_EXTERN_METHOD(fetchCallLogsData:(NSString *)userName clientID:(NSString *)clientID clientKey:(NSString *)clientKey serverURL:(NSString *)serverURL dateFrom:(NSString *)dateFrom resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

@end