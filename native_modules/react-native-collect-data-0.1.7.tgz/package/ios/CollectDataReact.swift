import Foundation
import CollectDeviceIOSData

@objc(CollectDataReact)
class CollectDataReact: NSObject {

  @objc(multiply:withB:withResolver:withRejecter:)
  func multiply(a: Float, b: Float, resolve:RCTPromiseResolveBlock,reject:RCTPromiseRejectBlock) -> Void {
    resolve(a*b)
  }

 @objc
  func disableSyncs(_ syncsDisabled: [String]) {
    CollectDeviceIOSData.CollectDeviceFeatures.disableSync(syncsDisabled:syncsDisabled);
    // resolve("Syncs Disabled")
  }

  @objc
  func syncDeviceLocationAppsData(_ userName: String, clientID: String, clientKey: String, serverURL: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
    CollectDeviceIOSData.CollectDeviceFeatures.syncDeviceData(userName: userName, clientId: clientID, clientKey: clientKey, serverURL: serverURL)
    { result in
        switch result {
        case .success(let data):
            resolve("Device Data Synced Successfully!")
        case .failure(let error):
            print("SDK:SyncDeviceData: \(error.localizedDescription)")
            reject("SDK:SyncDeviceData", "\(error.localizedDescription)", nil)
        }
    }
  }

  @objc
  func syncSMSData(_ userName: String, clientID: String, clientKey: String, serverURL: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
    CollectDeviceIOSData.CollectDeviceFeatures.syncSMSData(userName: userName, clientId: clientID, clientKey: clientKey, serverURL: serverURL)
    { result in
        switch result {
        case .success(let data):
            resolve("SMS Data Synced Successfully!")
        case .failure(let error):
            print("SDK:SyncSMSData: \(error.localizedDescription)")
            reject("SDK:SyncSMSData", "\(error.localizedDescription)", nil)
        }
    }
  }

  // @objc
  // func syncContactsData(_ userName: String, clientID: String, clientKey: String, serverURL: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
  //   CollectDeviceIOSData.CollectDeviceFeatures.syncContactsData(userName: userName, clientId: clientID, clientKey: clientKey, serverURL: serverURL)
  //   { result in
  //       switch result {
  //       case .success(let data):
  //           resolve("Contacts Data Synced Successfully!")
  //       case .failure(let error):
  //           print("SDK:SyncContactsData: \(error.localizedDescription)")
  //           reject("SDK:SyncContactsData", "\(error.localizedDescription)", nil)
  //       }
  //   }
  // }

  // @objc
  // func syncCallLogsData(_ userName: String, clientID: String, clientKey: String, serverURL: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
  //   CollectDeviceIOSData.CollectDeviceFeatures.syncCallLogsData(userName: userName, clientId: clientID, clientKey: clientKey, serverURL: serverURL)
  //   { result in
  //       switch result {
  //       case .success(let data):
  //           resolve("Call logs Data Synced Successfully!")
  //       case .failure(let error):
  //           print("SDK:SyncCallLogsData: \(error.localizedDescription)")
  //           reject("SDK:SyncCallLogsData", "\(error.localizedDescription)", nil)
  //       }
  //   }
  // }


  @objc
  func fetchDeviceData(_ userName: String, clientID: String, clientKey: String, serverURL: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
    CollectDeviceIOSData.CollectDeviceFeatures.fetchDeviceData(userName: userName, clientId: clientID, clientKey: clientKey)
    { result in
        switch result {
        case .success(let data):
            print("Device Data Fetched Successfully!")
            print(data)
            resolve(data)
        case .failure(let error):
            print("SDK:FetchDeviceData: \(error.localizedDescription)")
            reject("SDK:FetchDeviceData", "\(error.localizedDescription)", nil)
        }
    }
  }


// @objc
//   func fetchContactsData(_ userName: String, clientID: String, clientKey: String, serverURL: String, dateFrom: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
//     CollectDeviceIOSData.CollectDeviceFeatures.fetchContactsData(userName: userName, clientId: clientID, clientKey: clientKey)
//     { result in
//         switch result {
//         case .success(let data):
//             print("Contacts Data Fetched Successfully!")
//             print(data)
//             resolve(data)
//         case .failure(let error):
//             print("SDK:FetchContactsData: \(error.localizedDescription)")
//             reject("SDK:FetchContactsData", "\(error.localizedDescription)", nil)
//         }
//     }
//   }

// @objc
//   func fetchCallLogsData(_ userName: String, clientID: String, clientKey: String, serverURL: String,dateFrom: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
//     CollectDeviceIOSData.CollectDeviceFeatures.fetchCallLogsData(userName: userName, clientId: clientID, clientKey: clientKey)
//     { result in
//         switch result {
//         case .success(let data):
//             print("Call Logs Data Fetched Successfully!")
//             print(data)
//             resolve(data)
//         case .failure(let error):
//             print("SDK:FetchCallLogsData: \(error.localizedDescription)")
//             reject("SDK:FetchCallLogsData", "\(error.localizedDescription)", nil)
//         }
//     }
//   }

  @objc
  func fetchSMSInfo(_ userName: String, clientID: String, clientKey: String, serverURL: String, dateFrom: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
    CollectDeviceIOSData.CollectDeviceFeatures.fetchSMSData(userName: userName, clientId: clientID, clientKey: clientKey)
    { result in
        switch result {
        case .success(let data):
            print("SMS Data Fetched Successfully!")
            print(data)
            resolve(data)
        case .failure(let error):
            print("SDK:FetchSMSData: \(error.localizedDescription)")
            reject("SDK:FetchSMSData", "\(error.localizedDescription)", nil)
        }
    }
  }
  
  @objc
  func syncAllData(_ userName: String, clientID: String, clientKey: String, serverURL: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
    CollectDeviceIOSData.CollectDeviceFeatures.syncAllData(userName: userName, clientId: clientID, clientKey: clientKey, serverURL: serverURL)
    { result in
        switch result {
        case .success(let data):
            resolve("All Data Synced Successfully!")
            print(data)
        case .failure(let error):
            print("SDK:SyncAllData: \(error.localizedDescription)")
            reject("SDK:SyncAllData", "\(error.localizedDescription)", nil)
        }
    }
  }
  @objc
  func startBackGroundSyncProcess(_ userName: String, clientID: String, clientKey: String, serverURL: String, gapSeconds: Double, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
    CollectDeviceIOSData.CollectDeviceFeatures.syncAllData(userName: userName, clientId: clientID, clientKey: clientKey, serverURL: serverURL)
    { result in
        switch result {
        case .success(let data):
            resolve("Device Data Synced and But Background Process Not Started!")
            print(data)
        case .failure(let error):
            print("SDK:StartBackgroundSyncProcess: \(error.localizedDescription)")
            reject("SDK:StartBackgroundSyncProcess", "\(error.localizedDescription)", nil)
        }
    }
  }

  @objc
  func stopBackGroundSyncProcess(_ resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) {
    reject("SDK:StopBackgroundSyncProcess", "1008: Process not Stopped. No Background Process Running.", nil)
  }

}
