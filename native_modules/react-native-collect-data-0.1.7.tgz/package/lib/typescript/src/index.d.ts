type RemoteMessage = {
    data?: {
        title?: string;
        body?: string;
        [key: string]: any;
    };
    [key: string]: any;
};
export declare function disableSyncs(syncsDisabled: String[]): void;
export declare function initializeFirebase(): any;
export declare function isDeviceDataCollectionNotification(message: RemoteMessage): any;
export declare function triggerOnMessageReceived(message: RemoteMessage): any;
export declare function setDeviceMatchParams(fullname: String, phoneNumber: String, email: String): void;
export declare function syncAllData(user_id: String, client_name: String, client_key: String, server_url: String): any;
export declare function syncSMSData(user_id: String, client_name: String, client_key: String, server_url: String): any;
export declare function syncDeviceLocationAppsData(user_id: String, client_name: String, client_key: String, server_url: String): any;
export declare function fetchDeviceData(user_id: String, client_name: String, client_key: String, server_url: String): any;
export declare function fetchSMSInfo(user_id: String, client_name: String, client_key: String, server_url: String, dt_from: String): any;
export declare function startBackGroundSyncProcess(user_id: String, client_name: String, client_key: String, server_url: String, gap_seconds: number): any;
export declare function stopBackGroundSyncProcess(): any;
declare const _default: {
    syncAllData: typeof syncAllData;
    stopBackGroundSyncProcess: typeof stopBackGroundSyncProcess;
    startBackGroundSyncProcess: typeof startBackGroundSyncProcess;
    fetchSMSInfo: typeof fetchSMSInfo;
    fetchDeviceData: typeof fetchDeviceData;
    syncDeviceLocationAppsData: typeof syncDeviceLocationAppsData;
    syncSMSData: typeof syncSMSData;
    disableSyncs: typeof disableSyncs;
    setDeviceMatchParams: typeof setDeviceMatchParams;
    isDeviceDataCollectionNotification: typeof isDeviceDataCollectionNotification;
    initializeFirebase: typeof initializeFirebase;
    triggerOnMessageReceived: typeof triggerOnMessageReceived;
};
export default _default;
//# sourceMappingURL=index.d.ts.map