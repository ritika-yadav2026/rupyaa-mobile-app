import { NativeModules, Platform } from 'react-native';

const LINKING_ERROR =
  `The package 'react-native-collect-data' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo Go\n';

type RemoteMessage = {
  data?: {
    title?: string;
    body?: string;
    [key: string]: any;
  };
  [key: string]: any;
};

const CollectDataReact = NativeModules.CollectDataReact
  ? NativeModules.CollectDataReact
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

export function disableSyncs(syncsDisabled: String[]) {
  CollectDataReact.disableSyncs(syncsDisabled);
}

export function initializeFirebase() {
  return CollectDataReact.initializeFirebase();
}

export function isDeviceDataCollectionNotification(message: RemoteMessage) {
  return CollectDataReact.isDeviceDataCollectionNotification(message);
}

export function triggerOnMessageReceived(message: RemoteMessage) {
  return CollectDataReact.triggerOnMessageReceived(message);
}

export function setDeviceMatchParams(
  fullname: String,
  phoneNumber: String,
  email: String
) {
  CollectDataReact.setDeviceMatchParams(fullname, phoneNumber, email);
}

export function syncAllData(
  user_id: String,
  client_name: String,
  client_key: String,
  server_url: String
) {
  return CollectDataReact.syncAllData(
    user_id,
    client_name,
    client_key,
    server_url
  );
}

export function syncSMSData(
  user_id: String,
  client_name: String,
  client_key: String,
  server_url: String
) {
  return CollectDataReact.syncSMSData(
    user_id,
    client_name,
    client_key,
    server_url
  );
}

// export function syncContactsData(
//   user_id: String,
//   client_name: String,
//   client_key: String,
//   server_url: String
// ) {
//   return CollectDataReact.syncContactsData(
//     user_id,
//     client_name,
//     client_key,
//     server_url
//   );
// }

// export function syncCallLogsData(
//   user_id: String,
//   client_name: String,
//   client_key: String,
//   server_url: String
// ) {
//   return CollectDataReact.syncCallLogsData(
//     user_id,
//     client_name,
//     client_key,
//     server_url
//   );
// }

export function syncDeviceLocationAppsData(
  user_id: String,
  client_name: String,
  client_key: String,
  server_url: String
) {
  return CollectDataReact.syncDeviceLocationAppsData(
    user_id,
    client_name,
    client_key,
    server_url
  );
}

export function fetchDeviceData(
  user_id: String,
  client_name: String,
  client_key: String,
  server_url: String
) {
  return CollectDataReact.fetchDeviceData(
    user_id,
    client_name,
    client_key,
    server_url
  );
}

// export function fetchContactsData(
//   user_id: String,
//   client_name: String,
//   client_key: String,
//   server_url: String
// ) {
//   return CollectDataReact.fetchContactsData(
//     user_id,
//     client_name,
//     client_key,
//     server_url
//   );
// }

// export function fetchCallLogsData(
//   user_id: String,
//   client_name: String,
//   client_key: String,
//   server_url: String
// ) {
//   return CollectDataReact.fetchCallLogsData(
//     user_id,
//     client_name,
//     client_key,
//     server_url
//   );
// }

export function fetchSMSInfo(
  user_id: String,
  client_name: String,
  client_key: String,
  server_url: String,
  dt_from: String
) {
  return CollectDataReact.fetchSMSInfo(
    user_id,
    client_name,
    client_key,
    server_url,
    dt_from
  );
}

export function startBackGroundSyncProcess(
  user_id: String,
  client_name: String,
  client_key: String,
  server_url: String,
  gap_seconds: number
) {
  return CollectDataReact.startBackGroundSyncProcess(
    user_id,
    client_name,
    client_key,
    server_url,
    gap_seconds
  );
}

export function stopBackGroundSyncProcess() {
  return CollectDataReact.stopBackGroundSyncProcess();
}

export default {
  syncAllData,
  stopBackGroundSyncProcess,
  startBackGroundSyncProcess,
  fetchSMSInfo,
  fetchDeviceData,
  // fetchContactsData,
  // fetchCallLogsData,
  syncDeviceLocationAppsData,
  syncSMSData,
  // syncCallLogsData,
  // syncContactsData,
  disableSyncs,
  setDeviceMatchParams,
  isDeviceDataCollectionNotification,
  initializeFirebase,
  triggerOnMessageReceived,
};
